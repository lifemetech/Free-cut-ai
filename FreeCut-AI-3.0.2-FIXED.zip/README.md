# FreeCut AI 3.0

One-click, free-first, on-device AI video editor for Android.

## AI engine
- Whisper Base on-device speech-to-text
- First-run automatic model download (~142 MB)
- After download, speech analysis is local/offline
- Speech-timestamp based smart cuts
- Auto captions from Whisper segments
- 9:16 / 1:1 / 16:9 reframing
- Auto zoom and color enhancement
- Silence skipping
- Background media-processing foreground service
- Live progress, elapsed time and estimated remaining time
- MP4 export to Movies/FreeCut AI

## Build
GitHub Actions uses JDK 17 and Gradle 8.9 and produces a Debug APK and Release AAB.

## Note
The current AI editor is deliberately honest about its capabilities: it uses Whisper speech segments for smart cuts/captions and Media3 for rendering. It does not claim face recognition, semantic hook scoring, B-roll generation, or beat-matched editing without dedicated models/algorithms.
