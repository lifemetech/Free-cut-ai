package com.freecut.ai

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer

internal object AudioExtractor {
    fun extractWav(context: Context, uri: android.net.Uri, outFile: File): Boolean {
        val resolver = context.contentResolver
        val extractor = MediaExtractor()
        try {
            resolver.openFileDescriptor(uri, "r")?.use { pfd -> extractor.setDataSource(pfd.fileDescriptor) }
            var track = -1
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) { track = i; break }
            }
            if (track < 0) return false
            extractor.selectTrack(track)
            val format = extractor.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return false
            val decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(format, null, null, 0)
            decoder.start()

            var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE, 16000)
            var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT, 1)
            val pcm = java.io.ByteArrayOutputStream()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false

            while (!outputDone) {
                if (!inputDone) {
                    val index = decoder.dequeueInputBuffer(10_000)
                    if (index >= 0) {
                        val input = decoder.getInputBuffer(index)!!
                        input.clear()
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(index, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(index, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIndex = decoder.dequeueOutputBuffer(info, 10_000)
                when {
                    outIndex >= 0 -> {
                        val buffer = decoder.getOutputBuffer(outIndex)
                        if (buffer != null && info.size > 0) {
                            val bytes = ByteArray(info.size)
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            buffer.get(bytes)
                            pcm.write(bytes)
                        }
                        decoder.releaseOutputBuffer(outIndex, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    }
                    outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val outFormat = decoder.outputFormat
                        sampleRate = outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE, sampleRate)
                        channels = outFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT, channels)
                    }
                }
            }
            decoder.stop()
            decoder.release()
            writeWav(outFile, pcm.toByteArray(), sampleRate, channels, 16)
            return true
        } catch (_: Exception) {
            return false
        } finally {
            extractor.release()
        }
    }

    private fun writeWav(file: File, data: ByteArray, sampleRate: Int, channels: Int, bits: Int) {
        file.parentFile?.mkdirs()
        RandomAccessFile(file, "rw").use { raf ->
            raf.setLength(0)
            raf.writeBytes("RIFF")
            writeIntLE(raf, 36 + data.size)
            raf.writeBytes("WAVE")
            raf.writeBytes("fmt ")
            writeIntLE(raf, 16)
            writeShortLE(raf, 1)
            writeShortLE(raf, channels)
            writeIntLE(raf, sampleRate)
            val byteRate = sampleRate * channels * bits / 8
            writeIntLE(raf, byteRate)
            writeShortLE(raf, channels * bits / 8)
            writeShortLE(raf, bits)
            raf.writeBytes("data")
            writeIntLE(raf, data.size)
            raf.write(data)
        }
    }

    private fun writeIntLE(raf: RandomAccessFile, v: Int) {
        raf.write(byteArrayOf((v and 255).toByte(), ((v shr 8) and 255).toByte(), ((v shr 16) and 255).toByte(), ((v shr 24) and 255).toByte()))
    }
    private fun writeShortLE(raf: RandomAccessFile, v: Int) {
        raf.write(byteArrayOf((v and 255).toByte(), ((v shr 8) and 255).toByte()))
    }
}
