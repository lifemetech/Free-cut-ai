package com.freecut.ai

import android.content.Context

internal data class EditState(
    val running: Boolean = false,
    val progress: Float = 0f,
    val stage: String = "Ready",
    val detail: String = "Select a video to begin.",
    val elapsedSec: Long = 0,
    val etaSec: Long = -1,
    val outputUri: String? = null,
    val error: String = ""
)

internal object EditStateStore {
    private const val PREF = "freecut_edit_state"
    private fun p(context: Context) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun write(context: Context, state: EditState) {
        p(context).edit()
            .putBoolean("running", state.running)
            .putFloat("progress", state.progress)
            .putString("stage", state.stage)
            .putString("detail", state.detail)
            .putLong("elapsed", state.elapsedSec)
            .putLong("eta", state.etaSec)
            .putString("output", state.outputUri)
            .putString("error", state.error)
            .apply()
    }

    fun read(context: Context): EditState = EditState(
        running = p(context).getBoolean("running", false),
        progress = p(context).getFloat("progress", 0f),
        stage = p(context).getString("stage", "Ready") ?: "Ready",
        detail = p(context).getString("detail", "Select a video to begin.") ?: "",
        elapsedSec = p(context).getLong("elapsed", 0),
        etaSec = p(context).getLong("eta", -1),
        outputUri = p(context).getString("output", null),
        error = p(context).getString("error", "") ?: ""
    )

    fun modelReady(context: Context): Boolean = java.io.File(context.getExternalFilesDir("models"), "ggml-base.bin").exists()
}
