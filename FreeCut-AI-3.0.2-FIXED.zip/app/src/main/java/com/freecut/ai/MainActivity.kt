package com.freecut.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)

        setContent { FreeCutApp() }
    }

    fun startEdit(uri: Uri) {
        val intent = Intent(this, VideoEditService::class.java).apply {
            action = VideoEditService.ACTION_START
            data = uri
            putExtra(VideoEditService.EXTRA_CAPTIONS, true)
            putExtra(VideoEditService.EXTRA_SMART_CUT, true)
            putExtra(VideoEditService.EXTRA_SILENCE, true)
            putExtra(VideoEditService.EXTRA_REFRAME, true)
            putExtra(VideoEditService.EXTRA_ZOOM, true)
            putExtra(VideoEditService.EXTRA_COLOR, true)
            putExtra(VideoEditService.EXTRA_AUDIO, true)
            putExtra(VideoEditService.EXTRA_PRESET, "SHORTS")
        }
        ContextCompat.startForegroundService(this, intent)
    }
}

@androidx.compose.runtime.Composable
private fun FreeCutApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selected by remember { mutableStateOf<Uri?>(null) }
    var state by remember { mutableStateOf(EditState()) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selected = uri
            state = EditState()
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            state = EditStateStore.read(context)
            delay(500)
        }
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Spacer(Modifier.height(10.dp))
                    Text("FreeCut AI", style = MaterialTheme.typography.headlineLarge)
                    Text("One-click AI Shorts editor • Free • Offline after model download")
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("AI Engine", style = MaterialTheme.typography.titleLarge)
                            Text("Whisper Base • local speech analysis • smart cuts • captions • 9:16 • auto zoom • color/audio")
                            Text(if (EditStateStore.modelReady(context)) "AI model: READY ✓" else "AI model: downloads automatically on first edit")
                        }
                    }
                }
                item {
                    Button(onClick = { picker.launch("video/*") }, Modifier.fillMaxWidth()) {
                        Text(if (selected == null) "SELECT VIDEO" else "CHANGE VIDEO")
                    }
                }
                item {
                    Button(
                        onClick = { selected?.let { (context as? MainActivity)?.startEdit(it) } },
                        enabled = selected != null && !state.running,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("ONE-CLICK AI EDIT") }
                }
                if (state.running || state.progress > 0f) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(state.stage, style = MaterialTheme.typography.titleMedium)
                                LinearProgressIndicator(progress = { state.progress }, Modifier.fillMaxWidth())
                                Text("${(state.progress * 100).toInt()}%")
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Elapsed: ${formatSeconds(state.elapsedSec)}")
                                    Text("Remaining: ${if (state.etaSec >= 0) formatSeconds(state.etaSec) else "calculating…"}")
                                }
                                Text(state.detail)
                            }
                        }
                    }
                }
                if (!state.running && state.outputUri != null) {
                    item {
                        OutlinedButton(onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "video/mp4"
                                putExtra(Intent.EXTRA_STREAM, Uri.parse(state.outputUri))
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(send, "Share FreeCut AI video"))
                        }, Modifier.fillMaxWidth()) { Text("SHARE FINAL VIDEO") }
                    }
                }
                if (state.error.isNotBlank()) item { Text(state.error, color = MaterialTheme.colorScheme.error) }
                item {
                    Text("Tip: first edit downloads the ~142 MB Whisper Base model. After that, speech analysis works locally without an API key.")
                }
            }
        }
    }
}

private fun formatSeconds(sec: Long): String {
    if (sec < 0) return "—"
    val m = sec / 60
    val s = sec % 60
    return "%02d:%02d".format(m, s)
}
