# FreeCut AI
Free-first Android one-click Shorts editor foundation.

Planned: smart cuts, silence removal, auto zoom/pan, face tracking, 9:16 reframe, captions, graphics/overlays, audio/color enhancement, beat-aware editing and 1080p export.

This first build is intentionally a small, verified foundation. Heavy local AI/video model binaries are not bundled until the target phone hardware is tested.
