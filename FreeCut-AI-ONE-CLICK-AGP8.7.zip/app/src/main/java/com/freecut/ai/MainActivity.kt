package com.freecut.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { FreeCutApp() } }
}

@Composable
fun FreeCutApp() {
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                Text("FreeCut AI", style = MaterialTheme.typography.headlineLarge)
                Text("One-click Shorts editor • Free-first • Offline")
                Spacer(Modifier.height(24.dp))
                Button(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("SELECT VIDEO") }
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Text("ONE-CLICK AI EDIT") }
                Spacer(Modifier.height(20.dp))
                Text("Planned engine: smart cuts, silence removal, auto zoom/pan, 9:16 reframe, captions, overlays, color/audio enhancement and export.")
            }
        }
    }
}
