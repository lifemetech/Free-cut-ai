# FreeCut AI 3.1.1

Free-first Android Shorts editor with a fast one-pass mode and step-by-step editing tools.

## New in 3.1.1
- Fast AI Edit: smart cuts + silence removal + kinetic word captions + 9:16 in one render.
- Step-by-step tools: Smart Cut, Silence, Kinetic Captions, 9:16, Auto Zoom, Color, Audio.
- Use Last Result to continue editing the generated video.
- Kinetic captions: one word at a time with local Whisper-derived timing.
- Export 2K: 1440p-class vertical output target (1440x2560 for 9:16 when supported by the device encoder).
- H.264/AAC output for broad Android compatibility.
- Conservative compatibility retry remains enabled for encoder failures.
- Speech model is downloaded only for speech-dependent tools.

## Build
Upload `FreeCut-AI-3.1.1-FAST-KINETIC-2K.zip` to the repository and run the included GitHub Actions workflow.

## Stability fixes in 3.1.1
- Fixed Media3 TextureOverlay generic type mismatch in kinetic captions.
- Fixed TextOverlay OverlaySettings override signature for Media3 1.6.1.
- Compatibility retry now falls back to 1080p when a 2K hardware encoder fails.
- Output MediaStore cleanup prevents orphaned entries after save failures.
- Silence mode now uses speech segments for actual video clipping instead of audio-only skipping.
- Workflow builds both Debug APK and Release AAB.
