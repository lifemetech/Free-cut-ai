package com.freecut.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        setContent { FreeCutApp() }
    }

    fun startEdit(uri: Uri, mode: String) {
        val intent = Intent(this, VideoEditService::class.java).apply {
            action = VideoEditService.ACTION_START
            data = uri
            putExtra(VideoEditService.EXTRA_MODE, mode)
            putExtra(VideoEditService.EXTRA_CAPTIONS, mode == VideoEditService.MODE_FULL_FAST || mode == VideoEditService.MODE_CAPTIONS)
            putExtra(VideoEditService.EXTRA_SMART_CUT, mode == VideoEditService.MODE_FULL_FAST || mode == VideoEditService.MODE_SMART_CUT || mode == VideoEditService.MODE_SILENCE)
            putExtra(VideoEditService.EXTRA_SILENCE, mode == VideoEditService.MODE_FULL_FAST || mode == VideoEditService.MODE_SILENCE)
            putExtra(VideoEditService.EXTRA_REFRAME, mode == VideoEditService.MODE_FULL_FAST || mode == VideoEditService.MODE_REFRAME || mode == VideoEditService.MODE_EXPORT_2K)
            putExtra(VideoEditService.EXTRA_ZOOM, mode == VideoEditService.MODE_ZOOM)
            putExtra(VideoEditService.EXTRA_COLOR, mode == VideoEditService.MODE_COLOR)
            putExtra(VideoEditService.EXTRA_AUDIO, mode == VideoEditService.MODE_AUDIO)
            putExtra(VideoEditService.EXTRA_PRESET, "SHORTS")
            putExtra(VideoEditService.EXTRA_OUTPUT_HEIGHT, if (mode == VideoEditService.MODE_EXPORT_2K) 2560 else 1080)
        }
        ContextCompat.startForegroundService(this, intent)
    }
}

@androidx.compose.runtime.Composable
private fun FreeCutApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selected by remember { mutableStateOf<Uri?>(null) }
    var state by remember { mutableStateOf(EditState()) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selected = uri
            state = EditState()
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            state = EditStateStore.read(context)
            delay(500)
        }
    }

    fun run(mode: String) {
        val uri = selected ?: return
        (context as? MainActivity)?.startEdit(uri, mode)
    }

    fun useLastResult() {
        state.outputUri?.let { selected = Uri.parse(it) }
    }

    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Spacer(Modifier.height(8.dp))
                    Text("FreeCut AI", style = MaterialTheme.typography.headlineLarge)
                    Text("Fast AI Shorts editor • Offline after model download")
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("AI Engine", style = MaterialTheme.typography.titleLarge)
                            Text("Whisper Base • Kinetic captions • smart cuts • 9:16 • 2K export")
                            Text(if (EditStateStore.modelReady(context)) "AI model: READY ✓" else "AI model downloads only when a speech feature is used")
                        }
                    }
                }
                item {
                    Button(onClick = { picker.launch("video/*") }, Modifier.fillMaxWidth()) {
                        Text(if (selected == null) "SELECT VIDEO" else "CHANGE VIDEO")
                    }
                }
                item {
                    Text("FAST ONE-CLICK", style = MaterialTheme.typography.titleMedium)
                    Button(
                        onClick = { run(VideoEditService.MODE_FULL_FAST) },
                        enabled = selected != null && !state.running,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("⚡ FAST AI EDIT") }
                    Text("Smart cut + silence + kinetic captions + 9:16 in one render")
                }
                item {
                    Text("STEP-BY-STEP TOOLS", style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { run(VideoEditService.MODE_SMART_CUT) }, enabled = selected != null && !state.running, modifier = Modifier.weight(1f)) { Text("SMART CUT") }
                        Button(onClick = { run(VideoEditService.MODE_SILENCE) }, enabled = selected != null && !state.running, modifier = Modifier.weight(1f)) { Text("SILENCE") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { run(VideoEditService.MODE_CAPTIONS) }, enabled = selected != null && !state.running, modifier = Modifier.weight(1f)) { Text("KINETIC CAPTIONS") }
                        Button(onClick = { run(VideoEditService.MODE_REFRAME) }, enabled = selected != null && !state.running, modifier = Modifier.weight(1f)) { Text("9:16") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { run(VideoEditService.MODE_ZOOM) }, enabled = selected != null && !state.running, modifier = Modifier.weight(1f)) { Text("AUTO ZOOM") }
                        OutlinedButton(onClick = { run(VideoEditService.MODE_COLOR) }, enabled = selected != null && !state.running, modifier = Modifier.weight(1f)) { Text("COLOR") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { run(VideoEditService.MODE_AUDIO) }, enabled = selected != null && !state.running, modifier = Modifier.weight(1f)) { Text("AUDIO") }
                        OutlinedButton(onClick = { run(VideoEditService.MODE_EXPORT_2K) }, enabled = selected != null && !state.running, modifier = Modifier.weight(1f)) { Text("EXPORT 2K") }
                    }
                    Text("After each step, tap USE LAST RESULT to continue editing the generated video.")
                }
                if (state.running || state.progress > 0f) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Text(state.stage, style = MaterialTheme.typography.titleMedium)
                                LinearProgressIndicator(progress = { state.progress }, Modifier.fillMaxWidth())
                                Text("${(state.progress * 100).toInt()}%")
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Elapsed: ${formatSeconds(state.elapsedSec)}")
                                    Text("Remaining: ${if (state.etaSec >= 0) formatSeconds(state.etaSec) else "calculating…"}")
                                }
                                Text(state.detail)
                            }
                        }
                    }
                }
                if (!state.running && state.outputUri != null) {
                    item {
                        Button(onClick = { useLastResult() }, Modifier.fillMaxWidth()) { Text("USE LAST RESULT FOR NEXT STEP") }
                    }
                    item {
                        OutlinedButton(onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "video/mp4"
                                putExtra(Intent.EXTRA_STREAM, Uri.parse(state.outputUri))
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(send, "Share FreeCut AI video"))
                        }, Modifier.fillMaxWidth()) { Text("DOWNLOAD / SHARE FINAL VIDEO") }
                    }
                }
                if (state.error.isNotBlank()) item { Text(state.error, color = MaterialTheme.colorScheme.error) }
                item {
                    Text("Kinetic captions use word-level timing derived locally from Whisper. 2K mode targets 1440p-class vertical output (1440×2560 when the source/aspect allows it).")
                }
            }
        }
    }
}

private fun formatSeconds(sec: Long): String {
    if (sec < 0) return "—"
    val m = sec / 60
    val s = sec % 60
    return "%02d:%02d".format(m, s)
}
