# FreeCut AI — High Retention Editing Rulebook

This product does **not** apply an effect every second. Every second gets a story/attention decision. Editing density adapts to context.

## Core formula
RAW FOOTAGE → DEAD SPACE → STORY ORDER → HOOK → PACING → B-ROLL → SMART ZOOM → DYNAMIC CAPTIONS → GRAPHICS → SFX → MUSIC → PATTERN INTERRUPTS → RETENTION REVIEW → MANUAL REVIEW → FINAL RENDER

## Density
- LOW: 0–2 visual changes / 10s (emotional/storytelling)
- MEDIUM: 2–5 / 10s (normal explanation)
- HIGH: 5–10 / 10s (action/escalation)
- EXTREME: 8–15+ / 10s (hook/twist/climax)

## Shot-duration guidance
- Talking: 2–5s
- Important dialogue: 1–3s
- Action: 0.5–2s
- Reaction: 1–3s
- Emotional: 3–7s
- Establishing: 2–5s
- Cinematic: 4–8s

These are starting heuristics, not hard rules. The AI should preserve longer holds when clarity or emotion is stronger than visual change.

## Second-by-second decision signals
Speech, reaction, action, problem, reveal, B-roll, silence, numbers, money, time, important object, emotion, humor, new topic, climax, payoff.

## Golden rule
Every edit must have a reason: attention, clarity, emotion, story progression, or payoff. If no reason exists, do nothing.

## AI workflow
SELECT → CONFIGURE → ANALYZE → PREVIEW → APPLY → EDIT.

AI-generated operations must remain reviewable and editable; never lock the user into a single final render.
