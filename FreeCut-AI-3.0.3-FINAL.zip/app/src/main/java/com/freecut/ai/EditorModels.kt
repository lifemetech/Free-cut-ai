package com.freecut.ai

import android.net.Uri

data class MediaClip(
    val id: Long,
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val startMs: Long = 0L,
    val endMs: Long = durationMs,
    val linkedAudio: Boolean = true
)

enum class EditorTool(val label: String, val icon: String) {
    EDIT("Edit", "✂"), EFFECTS("Effects", "🎨"), TEXT("Text", "T"), AUDIO("Audio", "♫"), AI("AI", "🤖"), GRAPHICS("Graphics", "◆"), SPEED("Speed", "⚡"), ANIMATION("Animation", "◈"), MORE("More", "•••")
}

enum class CaptionStyle(val label: String) {
    KINETIC_PRO("Kinetic Pro"), WORD_POP("Word Pop"), HIGHLIGHT("Highlight"), KARAOKE("Karaoke"), TWO_WORD("2 Word"), THREE_WORD("3 Word"), MINIMAL("Minimal")
}

data class ProjectSettings(
    val name: String = "My YouTube Video",
    val aspectRatio: String = "9:16",
    val resolution: String = "1080p",
    val fps: Int = 30
)

sealed class EditCommand(val title: String) {
    data class AddClip(val clip: MediaClip): EditCommand("Add clip")
    data class Trim(val clipId: Long, val startMs: Long, val endMs: Long): EditCommand("Trim clip")
    data class Split(val clipId: Long, val timeMs: Long): EditCommand("Split clip")
    data class Delete(val clipId: Long): EditCommand("Delete clip")
    data class ApplyTool(val tool: EditorTool, val preset: String): EditCommand("${tool.label}: $preset")
}
