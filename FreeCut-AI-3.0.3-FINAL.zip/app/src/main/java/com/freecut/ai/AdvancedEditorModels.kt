package com.freecut.ai

import android.net.Uri

/** Non-destructive project graph used by both manual tools and AI planning. */
data class EditorProject(
    val id: String,
    val name: String,
    val settings: ProjectSettings,
    val media: List<MediaClip> = emptyList(),
    val tracks: List<EditorTrack> = emptyList(),
    val commands: List<EditCommand> = emptyList()
)

enum class TrackType { VIDEO, OVERLAY, TEXT, VOICE, MUSIC, SFX, AMBIENT, GRAPHICS }

data class EditorTrack(
    val id: Long,
    val type: TrackType,
    val name: String,
    val clips: List<TimelineItem> = emptyList(),
    val muted: Boolean = false,
    val solo: Boolean = false,
    val volumeDb: Float = 0f
)

sealed class TimelineItem {
    abstract val id: Long
    abstract val startMs: Long
    abstract val durationMs: Long
    data class Source(override val id: Long, override val startMs: Long, override val durationMs: Long, val uri: Uri) : TimelineItem()
    data class Text(override val id: Long, override val startMs: Long, override val durationMs: Long, val text: String, val style: CaptionStyle) : TimelineItem()
    data class Graphic(override val id: Long, override val startMs: Long, override val durationMs: Long, val kind: String) : TimelineItem()
}

data class Keyframe<T>(val timeMs: Long, val value: T)
data class TransformKeyframes(
    val position: List<Keyframe<Pair<Float, Float>>> = emptyList(),
    val scale: List<Keyframe<Float>> = emptyList(),
    val rotation: List<Keyframe<Float>> = emptyList(),
    val opacity: List<Keyframe<Float>> = emptyList(),
    val blur: List<Keyframe<Float>> = emptyList()
)

data class AiEditDecision(
    val second: Int,
    val role: RetentionEngine.ShotRole,
    val action: String,
    val reason: String,
    val confidence: Float,
    val editable: Boolean = true
)

data class AiEditDraft(
    val preset: String,
    val decisions: List<AiEditDecision>,
    val score: Int,
    val requiresReview: Boolean = true
)
