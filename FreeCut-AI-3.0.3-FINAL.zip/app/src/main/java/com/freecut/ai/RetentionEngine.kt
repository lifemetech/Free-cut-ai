package com.freecut.ai

import kotlin.math.max

/**
 * Free-first, deterministic high-retention planner.
 * It deliberately does NOT force an edit every second. It changes editing density
 * according to story signals and produces an editable plan for the timeline UI.
 */
object RetentionEngine {
    enum class Density(val changesPer10s: IntRange) {
        LOW(0..2), MEDIUM(2..5), HIGH(5..10), EXTREME(8..15)
    }

    enum class ShotRole { HOOK, PROMISE, CONTEXT, ACTION, PROBLEM, ESCALATION, TWIST, PAYOFF, VALUE, CTA, EMOTIONAL }

    data class SecondDecision(
        val second: Int,
        val role: ShotRole,
        val density: Density,
        val action: String,
        val reason: String,
        val zoomPercent: Int = 100,
        val caption: String = "",
        val sfx: String = "",
        val musicDb: Int = 0,
        val allowHold: Boolean = false
    )

    data class PlanSummary(
        val score: Int,
        val decisions: List<SecondDecision>,
        val strengths: List<String>,
        val warnings: List<String>
    )

    fun build(durationMs: Long, transcript: String = ""): PlanSummary {
        val total = max(1, ((durationMs + 999) / 1000).toInt())
        val list = ArrayList<SecondDecision>(total)
        for (sec in 0 until total) {
            val role = roleFor(sec, total)
            val density = densityFor(role, sec, total)
            val decision = when (role) {
                ShotRole.HOOK -> SecondDecision(sec, role, density, "HARD CUT + IMPACT", "Immediate curiosity", 110, hookCaption(transcript), "impact", -4)
                ShotRole.PROMISE -> SecondDecision(sec, role, density, "CLEAN SHOT + TEXT", "Clarify the promise", 100, "THE GOAL", "whoosh", -6)
                ShotRole.CONTEXT -> SecondDecision(sec, role, density, "HOLD / PUNCH-IN ONLY IF NEEDED", "Clarity over visual noise", 103, "", "", -10, true)
                ShotRole.ACTION -> SecondDecision(sec, role, density, "ACTION CUT / B-ROLL", "Move the story forward", 106, "", "light hit", -8)
                ShotRole.PROBLEM -> SecondDecision(sec, role, density, "REACTION + CLOSE-UP", "Make the obstacle visible", 112, "PROBLEM", "impact", -6)
                ShotRole.ESCALATION -> SecondDecision(sec, role, density, "MONTAGE / PROGRESS", "Increase stakes", 108, "PROGRESS", "riser", -5)
                ShotRole.TWIST -> SecondDecision(sec, role, density, "PAUSE + REVEAL", "Reset attention before reveal", 100, "WAIT…", "hit", -12)
                ShotRole.PAYOFF -> SecondDecision(sec, role, density, "RESULT + REACTION", "Deliver the promised payoff", 100, "RESULT", "impact", -3)
                ShotRole.VALUE -> SecondDecision(sec, role, density, "PROOF / B-ROLL", "Support the takeaway", 102, "", "", -9, true)
                ShotRole.CTA -> SecondDecision(sec, role, density, "TEASE + CTA", "Give a reason to continue", 103, "NEXT VIDEO →", "soft hit", -8)
                ShotRole.EMOTIONAL -> SecondDecision(sec, role, density, "LONGER NATURAL SHOT", "Emotion benefits from breathing room", 100, "", "", -14, true)
            }
            list += decision
        }
        val score = (78 + (if (transcript.isNotBlank()) 8 else 0) - (if (total < 20) 5 else 0)).coerceIn(0, 100)
        return PlanSummary(
            score,
            list,
            listOf("Density changes with story role", "Quiet moments are preserved", "AI decisions are editable", "Hook → stakes → payoff structure"),
            listOf("Final plan is a starting point; review AI cuts before export", "Word timing requires a transcript model with word timestamps")
        )
    }

    private fun roleFor(sec: Int, total: Int): ShotRole {
        val p = sec.toFloat() / total
        return when {
            p < 0.01f -> ShotRole.HOOK
            p < 0.025f -> ShotRole.PROMISE
            p < 0.10f -> ShotRole.CONTEXT
            p < 0.20f -> ShotRole.ACTION
            p < 0.30f -> ShotRole.PROBLEM
            p < 0.40f -> ShotRole.ESCALATION
            p < 0.50f -> ShotRole.TWIST
            p < 0.65f -> ShotRole.ACTION
            p < 0.72f -> ShotRole.PAYOFF
            p < 0.82f -> ShotRole.EMOTIONAL
            p < 0.94f -> ShotRole.VALUE
            else -> ShotRole.CTA
        }
    }

    private fun densityFor(role: ShotRole, sec: Int, total: Int): Density = when (role) {
        ShotRole.HOOK, ShotRole.TWIST, ShotRole.PAYOFF -> Density.EXTREME
        ShotRole.ACTION, ShotRole.ESCALATION, ShotRole.PROBLEM -> Density.HIGH
        ShotRole.PROMISE, ShotRole.VALUE, ShotRole.CTA -> Density.MEDIUM
        ShotRole.CONTEXT, ShotRole.EMOTIONAL -> Density.LOW
    }

    private fun hookCaption(transcript: String): String {
        val words = transcript.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        return if (words.isEmpty()) "I HAVE 24 HOURS…" else words.take(5).joinToString(" ").uppercase()
    }
}
