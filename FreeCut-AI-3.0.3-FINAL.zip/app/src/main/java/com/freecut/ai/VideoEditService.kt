package com.freecut.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media3.common.MimeTypes
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.exoplayer.audio.SilenceSkippingAudioProcessor
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

@UnstableApi
class VideoEditService : Service() {
    companion object {
        const val ACTION_START = "com.freecut.ai.START_EDIT"
        const val EXTRA_MODE = "mode"
        const val EXTRA_CAPTIONS = "captions"
        const val EXTRA_SMART_CUT = "smartCut"
        const val EXTRA_SILENCE = "silence"
        const val EXTRA_REFRAME = "reframe"
        const val EXTRA_ZOOM = "zoom"
        const val EXTRA_COLOR = "color"
        const val EXTRA_AUDIO = "audio"
        const val EXTRA_PRESET = "preset"
        const val EXTRA_OUTPUT_HEIGHT = "outputHeight"
        const val EXTRA_START_MS = "startMs"
        const val EXTRA_END_MS = "endMs"

        const val MODE_FULL_FAST = "FULL_FAST"
        const val MODE_SMART_CUT = "SMART_CUT"
        const val MODE_SILENCE = "SILENCE"
        const val MODE_CAPTIONS = "CAPTIONS"
        const val MODE_REFRAME = "REFRAME"
        const val MODE_ZOOM = "ZOOM"
        const val MODE_COLOR = "COLOR"
        const val MODE_AUDIO = "AUDIO"
        const val MODE_EXPORT_2K = "EXPORT_2K"
        const val MODE_TRIM = "TRIM"
        const val MODE_SPLIT = "SPLIT"

        private const val CHANNEL = "freecut_processing"
        private const val NOTIFICATION_ID = 77
        private const val MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin"
        private const val MODEL_NAME = "ggml-base.bin"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var transformer: Transformer? = null
    private var outputTemp: File? = null
    private var startElapsed = 0L
    private var safeRetryUsed = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START || intent.data == null) return START_NOT_STICKY
        startForegroundCompat()
        scope.launch { runPipeline(intent.data!!, intent) }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val notification = notification("Preparing FreeCut AI…", 1)
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            notification,
            if (Build.VERSION.SDK_INT >= 35) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING else 0
        )
    }

    private suspend fun runPipeline(uri: Uri, intent: Intent) {
        startElapsed = SystemClock.elapsedRealtime()
        safeRetryUsed = false
        val mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_FULL_FAST
        val needsSpeech = intent.getBooleanExtra(EXTRA_CAPTIONS, false) || intent.getBooleanExtra(EXTRA_SMART_CUT, false)
        setState(true, 0.01f, "Starting", "Preparing $mode…", -1, null, "")

        try {
            var usable = listOf(SpeechSegment(0, durationMs(uri), ""))

            if (needsSpeech) {
                val model = File(getExternalFilesDir("models"), MODEL_NAME)
                if (!model.exists()) downloadModel(model)

                setState(true, 0.16f, "Extracting audio", "Creating local 16 kHz WAV for Whisper…", -1, null, "")
                val wav = File(cacheDir, "whisper_${System.currentTimeMillis()}.wav")
                if (!AudioExtractor.extractWav(this, uri, wav)) {
                    throw IllegalStateException("Audio extraction failed. Try another video.")
                }

                setState(true, 0.30f, "AI speech analysis", "Whisper Base is transcribing locally…", -1, null, "")
                val whisperModel = Whisper.loadModel(this, model.absolutePath)
                val result = try {
                    Whisper.transcribe(whisperModel, wav.absolutePath, WhisperConfig())
                } finally {
                    Whisper.releaseModel(whisperModel)
                }
                wav.delete()

                val duration = durationMs(uri)
                val segments = result.segments.mapNotNull {
                    val s = max(0L, it.startMs)
                    val e = minOf(duration, it.endMs)
                    if (e - s >= 180) SpeechSegment(s, e, it.text.trim()) else null
                }
                usable = if (segments.isEmpty()) {
                    listOf(SpeechSegment(0, duration, result.text.trim()))
                } else segments
            }

            setState(true, 0.55f, "Building edit", "Preparing ${modeLabel(mode)}…", -1, null, "")
            val composition = buildComposition(
                uri = uri,
                segments = usable,
                captions = intent.getBooleanExtra(EXTRA_CAPTIONS, false),
                smartCut = intent.getBooleanExtra(EXTRA_SMART_CUT, false),
                silence = intent.getBooleanExtra(EXTRA_SILENCE, false),
                reframe = intent.getBooleanExtra(EXTRA_REFRAME, false),
                zoom = intent.getBooleanExtra(EXTRA_ZOOM, false),
                color = intent.getBooleanExtra(EXTRA_COLOR, false),
                audio = intent.getBooleanExtra(EXTRA_AUDIO, false),
                preset = intent.getStringExtra(EXTRA_PRESET) ?: "SHORTS",
                outputHeight = intent.getIntExtra(EXTRA_OUTPUT_HEIGHT, 1080),
                trimStartMs = intent.getLongExtra(EXTRA_START_MS, 0L),
                trimEndMs = intent.getLongExtra(EXTRA_END_MS, -1L)
            )

            outputTemp = File(cacheDir, "freecut_${System.currentTimeMillis()}.mp4")
            startTransformer(composition, outputTemp!!, usable, uri, mode, intent)
        } catch (e: Exception) {
            finishError(e.message ?: "Editing failed")
        }
    }

    private suspend fun startTransformer(
        composition: Composition,
        output: File,
        usable: List<SpeechSegment>,
        uri: Uri,
        mode: String,
        intent: Intent
    ) {
        withContext(Dispatchers.Main.immediate) {
            transformer = Transformer.Builder(this@VideoEditService)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        scope.launch { finishSuccess(output) }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        scope.launch {
                            if (!safeRetryUsed) {
                                safeRetryUsed = true
                                retrySafeExport(
                                    uri = uri,
                                    clips = usable,
                                    preset = intent.getStringExtra(EXTRA_PRESET) ?: "SHORTS",
                                    outputHeight = intent.getIntExtra(EXTRA_OUTPUT_HEIGHT, 1080)
                                )
                            } else {
                                finishError(
                                    "Export failed: ${exportException.errorCodeName}. " +
                                        "Try Fast AI Edit or export at 1080p on this device."
                                )
                            }
                        }
                    }
                })
                .build()

            setState(true, 0.60f, "Rendering video", "Encoding one optimized MP4 pass…", -1, null, "")
            transformer!!.start(composition, output.absolutePath)
        }
        withContext(Dispatchers.Main.immediate) { pollProgress() }
    }

    private suspend fun retrySafeExport(
        uri: Uri,
        clips: List<SpeechSegment>,
        preset: String,
        outputHeight: Int
    ) {
        try { transformer?.cancel() } catch (_: Exception) {}
        outputTemp?.delete()
        outputTemp = File(cacheDir, "freecut_safe_${System.currentTimeMillis()}.mp4")

        val safeItems = clips.map { seg ->
            val start = max(0L, seg.startMs)
            val end = max(start + 100L, seg.endMs)
            val media = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(start)
                        .setEndPositionMs(end)
                        .build()
                ).build()

            val effects = mutableListOf<androidx.media3.common.Effect>()
            val aspect = when (preset) {
                "SQUARE" -> 1f
                "YOUTUBE" -> 16f / 9f
                else -> 9f / 16f
            }
            effects.add(Presentation.createForAspectRatio(aspect, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            if (outputHeight > 1080) effects.add(Presentation.createForHeight(outputHeight))

            EditedMediaItem.Builder(media)
                .setEffects(Effects(emptyList(), effects))
                .build()
        }

        val safeComposition = Composition.Builder(listOf(EditedMediaItemSequence(safeItems.toList()))).build()

        withContext(Dispatchers.Main.immediate) {
            setState(true, 0.60f, "Compatibility export", "Retrying with conservative H.264/AAC encoding…", -1, null, "")
            transformer = Transformer.Builder(this@VideoEditService)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        scope.launch { finishSuccess(outputTemp!!) }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        scope.launch { finishError("Export failed after compatibility retry: ${exportException.errorCodeName}") }
                    }
                })
                .build()
            transformer!!.start(safeComposition, outputTemp!!.absolutePath)
        }
        withContext(Dispatchers.Main.immediate) { pollProgress() }
    }

    private suspend fun pollProgress() {
        val holder = ProgressHolder()
        while (transformer != null) {
            val state = transformer!!.getProgress(holder)
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                val raw = holder.progress / 100f
                val p = 0.60f + raw * 0.40f
                val elapsed = (SystemClock.elapsedRealtime() - startElapsed) / 1000L
                val eta = if (raw > 0.02f) ((elapsed / raw) - elapsed).toLong() else -1L
                setState(true, p, "Rendering video", "Media3 is encoding the final MP4…", eta, null, "")
                updateNotification("Rendering video", (p * 100).toInt())
            }
            delay(500)
        }
    }

    private fun buildComposition(
        uri: Uri,
        segments: List<SpeechSegment>,
        captions: Boolean,
        smartCut: Boolean,
        silence: Boolean,
        reframe: Boolean,
        zoom: Boolean,
        color: Boolean,
        audio: Boolean,
        preset: String,
        outputHeight: Int,
        trimStartMs: Long = 0L,
        trimEndMs: Long = -1L
    ): Composition {
        val useSegments = (smartCut || captions) && segments.size > 1
        val clips = if (useSegments) {
            val padding = 120L
            val gapThreshold = 650L
            val merged = ArrayList<SpeechSegment>()
            for (seg in segments) {
                val s = max(0L, seg.startMs - padding)
                val e = seg.endMs + padding
                if (merged.isNotEmpty() && s - merged.last().endMs < gapThreshold) {
                    val last = merged.removeAt(merged.lastIndex)
                    merged.add(SpeechSegment(last.startMs, max(last.endMs, e), (last.text + " " + seg.text).trim()))
                } else merged.add(SpeechSegment(s, e, seg.text))
            }
            merged
        } else listOf(SpeechSegment(0, durationMs(uri), ""))

        val sourceClips = if (trimEndMs > trimStartMs) {
            listOf(SpeechSegment(trimStartMs, trimEndMs, ""))
        } else clips

        val items = sourceClips.map { seg ->
            val media = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(seg.startMs)
                        .setEndPositionMs(max(seg.startMs + 100, seg.endMs))
                        .build()
                ).build()

            val effects = mutableListOf<androidx.media3.common.Effect>()
            if (reframe) {
                val aspect = when (preset) {
                    "SQUARE" -> 1f
                    "YOUTUBE" -> 16f / 9f
                    else -> 9f / 16f
                }
                effects.add(Presentation.createForAspectRatio(aspect, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
                if (outputHeight > 1080) effects.add(Presentation.createForHeight(outputHeight))
            }
            if (zoom) effects.add(ScaleAndRotateTransformation.Builder().setScale(1.035f, 1.035f).build())
            if (color) {
                effects.add(Brightness(0.025f))
                effects.add(Contrast(0.05f))
            }
            if (captions && seg.text.isNotBlank()) {
                val wordCues = buildWordCues(seg.text, seg.endMs - seg.startMs)
                val settings = StaticOverlaySettings.Builder()
                    .setBackgroundFrameAnchor(0f, -0.70f)
                    .setOverlayFrameAnchor(0f, -0.70f)
                    .build()
                effects.add(OverlayEffect(mutableListOf<androidx.media3.effect.TextureOverlay>(KineticWordOverlay(wordCues, settings))))
            }

            val audioProcessors = mutableListOf<androidx.media3.common.audio.AudioProcessor>()
            if (silence) {
                val skip = SilenceSkippingAudioProcessor()
                skip.setEnabled(true)
                audioProcessors.add(skip)
            }
            EditedMediaItem.Builder(media).setEffects(Effects(audioProcessors, effects)).build()
        }

        return Composition.Builder(listOf(EditedMediaItemSequence(items.toList()))).build()
    }

    private fun buildWordCues(text: String, durationMs: Long): List<WordCue> {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.take(80)
        if (words.isEmpty()) return emptyList()
        val perWord = (durationMs.coerceAtLeast(400L).toDouble() / words.size).toLong()
        return words.mapIndexed { index, word ->
            val start = index * perWord
            val end = if (index == words.lastIndex) durationMs.coerceAtLeast(start + 80L) else ((index + 1) * perWord)
            WordCue(start * 1000L, max(start + 80L, end) * 1000L, word)
        }
    }

    private fun modeLabel(mode: String): String = when (mode) {
        MODE_FULL_FAST -> "Fast AI edit"
        MODE_SMART_CUT -> "smart cuts"
        MODE_SILENCE -> "silence removal"
        MODE_CAPTIONS -> "kinetic word captions"
        MODE_REFRAME -> "9:16 reframe"
        MODE_ZOOM -> "auto zoom"
        MODE_COLOR -> "color enhancement"
        MODE_AUDIO -> "audio cleanup"
        MODE_EXPORT_2K -> "2K export"
        MODE_TRIM -> "trim"
        MODE_SPLIT -> "split"
        else -> "edit"
    }

    private suspend fun downloadModel(file: File) {
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, "$MODEL_NAME.part")
        val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 60_000
            instanceFollowRedirects = true
        }
        conn.connect()
        if (conn.responseCode !in 200..299) throw IllegalStateException("AI model download failed: HTTP ${conn.responseCode}")
        val total = conn.contentLengthLong
        var done = 0L
        conn.inputStream.use { input ->
            FileOutputStream(tmp).use { output ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    output.write(buf, 0, n)
                    done += n
                    val frac = if (total > 0) done.toFloat() / total else 0f
                    val p = 0.01f + frac * 0.14f
                    val elapsed = (SystemClock.elapsedRealtime() - startElapsed) / 1000L
                    val eta = if (frac > 0.02f) ((elapsed / frac) - elapsed).toLong() else -1L
                    setState(true, p, "Downloading AI model", "Whisper Base • ${(done / 1_000_000)} / ${(total / 1_000_000)} MB", eta, null, "")
                    updateNotification("Downloading AI model", (frac * 100).toInt())
                }
            }
        }
        if (tmp.length() < 50_000_000L) throw IllegalStateException("Downloaded AI model is incomplete")
        if (file.exists()) file.delete()
        if (!tmp.renameTo(file)) throw IllegalStateException("Could not store AI model")
    }

    private fun durationMs(uri: Uri): Long {
        val r = android.media.MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) { 0L } finally { r.release() }
    }

    private suspend fun finishSuccess(temp: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "FreeCut_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, android.os.Environment.DIRECTORY_MOVIES + "/FreeCut AI")
            }
            val saved = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create output file")
            contentResolver.openOutputStream(saved)?.use { out -> temp.inputStream().use { it.copyTo(out) } }
            temp.delete()
            setState(false, 1f, "Complete ✓", "Saved to Movies/FreeCut AI", 0, saved, "")
            updateNotification("FreeCut AI complete", 100)
            stopNow()
        } catch (e: Exception) {
            finishError(e.message ?: "Saving failed")
        }
    }

    private fun finishError(message: String) {
        try { outputTemp?.delete() } catch (_: Exception) {}
        setState(false, 0f, "Failed", "", 0, null, message)
        updateNotification("FreeCut AI failed", 0)
        stopNow()
    }

    private fun setState(running: Boolean, progress: Float, stage: String, detail: String, eta: Long, output: Uri?, error: String) {
        val elapsed = (SystemClock.elapsedRealtime() - startElapsed) / 1000L
        EditStateStore.write(this, EditState(running, progress.coerceIn(0f, 1f), stage, detail, elapsed, eta, output?.toString(), error))
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "FreeCut AI Processing", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(text: String, progress: Int): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("FreeCut AI")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .build()
    }

    private fun updateNotification(text: String, progress: Int) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text, progress))
    }

    private fun stopNow() {
        transformer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        transformer = null
        scope.cancel()
        super.onDestroy()
    }

    private data class SpeechSegment(val startMs: Long, val endMs: Long, val text: String)
    private data class WordCue(val startUs: Long, val endUs: Long, val word: String)

    private class KineticWordOverlay(
        private val words: List<WordCue>,
        private val settings: StaticOverlaySettings
    ) : TextOverlay() {
        override fun getText(presentationTimeUs: Long): android.text.SpannableString {
            val current = words.lastOrNull { presentationTimeUs >= it.startUs && presentationTimeUs < it.endUs }
                ?: words.lastOrNull { presentationTimeUs >= it.endUs }
                ?: return android.text.SpannableString("")
            return android.text.SpannableString(current.word.uppercase()).apply {
                setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(android.text.style.ForegroundColorSpan(android.graphics.Color.WHITE), 0, length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(android.text.style.RelativeSizeSpan(1.15f), 0, length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }

        override fun getOverlaySettings(presentationTimeUs: Long): StaticOverlaySettings = settings
    }
}
