package com.freecut.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.exoplayer.audio.SilenceSkippingAudioProcessor
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max

@UnstableApi
class VideoEditService : Service() {
    companion object {
        const val ACTION_START = "com.freecut.ai.START_EDIT"
        const val EXTRA_CAPTIONS = "captions"
        const val EXTRA_SMART_CUT = "smartCut"
        const val EXTRA_SILENCE = "silence"
        const val EXTRA_REFRAME = "reframe"
        const val EXTRA_ZOOM = "zoom"
        const val EXTRA_COLOR = "color"
        const val EXTRA_AUDIO = "audio"
        const val EXTRA_PRESET = "preset"
        private const val CHANNEL = "freecut_processing"
        private const val NOTIFICATION_ID = 77
        private const val MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin"
        private const val MODEL_NAME = "ggml-base.bin"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var transformer: Transformer? = null
    private var outputTemp: File? = null
    private var startElapsed = 0L
    private var safeRetryUsed = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START || intent.data == null) return START_NOT_STICKY
        startForegroundCompat()
        scope.launch { runPipeline(intent.data!!, intent) }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val notification = notification("Preparing AI editor…", 1)
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            notification,
            if (Build.VERSION.SDK_INT >= 35) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING else 0
        )
    }

    private suspend fun runPipeline(uri: Uri, intent: Intent) {
        startElapsed = SystemClock.elapsedRealtime()
        safeRetryUsed = false
        setState(true, 0.01f, "Starting", "Preparing local AI engine…", -1, null, "")
        try {
            val model = File(getExternalFilesDir("models"), MODEL_NAME)
            if (!model.exists()) {
                downloadModel(model)
            }
            setState(true, 0.15f, "Extracting audio", "Creating local 16 kHz WAV for Whisper…", -1, null, "")
            val wav = File(cacheDir, "whisper_${System.currentTimeMillis()}.wav")
            if (!AudioExtractor.extractWav(this, uri, wav)) throw IllegalStateException("Audio extraction failed. Try another video.")

            setState(true, 0.30f, "AI speech analysis", "Whisper Base is transcribing locally…", -1, null, "")
            val whisperModel = Whisper.loadModel(this, model.absolutePath)
            val result = try {
                Whisper.transcribe(whisperModel, wav.absolutePath, WhisperConfig())
            } finally {
                Whisper.releaseModel(whisperModel)
            }
            wav.delete()

            val duration = durationMs(uri)
            val segments = result.segments.mapNotNull {
                val s = max(0L, it.startMs)
                val e = minOf(duration, it.endMs)
                if (e - s >= 180) SpeechSegment(s, e, it.text.trim()) else null
            }
            val usable = if (segments.isEmpty()) listOf(SpeechSegment(0, duration, result.text.trim())) else segments

            setState(true, 0.58f, "Building edit", "${usable.size} speech segments detected…", -1, null, "")
            val composition = buildComposition(
                uri = uri,
                segments = usable,
                captions = intent.getBooleanExtra(EXTRA_CAPTIONS, true),
                smartCut = intent.getBooleanExtra(EXTRA_SMART_CUT, true),
                silence = intent.getBooleanExtra(EXTRA_SILENCE, true),
                reframe = intent.getBooleanExtra(EXTRA_REFRAME, true),
                zoom = intent.getBooleanExtra(EXTRA_ZOOM, true),
                color = intent.getBooleanExtra(EXTRA_COLOR, true),
                audio = intent.getBooleanExtra(EXTRA_AUDIO, true),
                preset = intent.getStringExtra(EXTRA_PRESET) ?: "SHORTS"
            )

            outputTemp = File(cacheDir, "freecut_${System.currentTimeMillis()}.mp4")
            withContext(Dispatchers.Main.immediate) {
                transformer = Transformer.Builder(this@VideoEditService)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            scope.launch { finishSuccess(outputTemp!!) }
                        }
                        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                            scope.launch {
                                // Some Android devices fail when a hardware encoder is asked to
                                // process a complex effect chain. Retry once with a conservative
                                // Media3 composition that keeps the actual smart-cut clips but
                                // removes optional visual/audio processors.
                                if (!safeRetryUsed) {
                                    safeRetryUsed = true
                                    retrySafeExport(
                                        uri = uri,
                                        clips = usable,
                                        preset = intent.getStringExtra(EXTRA_PRESET) ?: "SHORTS"
                                    )
                                } else {
                                    finishError(
                                        "Export failed: ${exportException.errorCodeName}. " +
                                        "The device video encoder could not encode this video."
                                    )
                                }
                            }
                        }
                    }).build()

                setState(true, 0.62f, "Rendering video", "Applying cuts, captions and visual effects…", -1, null, "")
                transformer!!.start(composition, outputTemp!!.absolutePath)
            }
            withContext(Dispatchers.Main.immediate) { pollProgress() }
        } catch (e: Exception) {
            finishError(e.message ?: "Editing failed")
        }
    }

    private suspend fun retrySafeExport(
        uri: Uri,
        clips: List<SpeechSegment>,
        preset: String
    ) {
        try {
            transformer?.cancel()
        } catch (_: Exception) {
        }

        outputTemp?.delete()
        outputTemp = File(cacheDir, "freecut_safe_${System.currentTimeMillis()}.mp4")

        val safeItems = clips.map { seg ->
            val start = max(0L, seg.startMs)
            val end = max(start + 100L, seg.endMs)
            val media = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(start)
                        .setEndPositionMs(end)
                        .build()
                )
                .build()

            // Keep the 9:16/1:1/16:9 reframe, but avoid text/audio processors
            // during the compatibility retry.
            val effects = mutableListOf<androidx.media3.common.Effect>()
            val aspect = when (preset) {
                "SQUARE" -> 1f
                "YOUTUBE" -> 16f / 9f
                else -> 9f / 16f
            }
            effects.add(
                Presentation.createForAspectRatio(
                    aspect,
                    Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
                )
            )

            EditedMediaItem.Builder(media)
                .setEffects(Effects(emptyList(), effects))
                .build()
        }

        val safeComposition = Composition.Builder(
            listOf(EditedMediaItemSequence(safeItems.toList()))
        ).build()

        withContext(Dispatchers.Main.immediate) {
            setState(
                true,
                0.62f,
                "Compatibility export",
                "Retrying with device-safe video encoding…",
                -1,
                null,
                ""
            )

            transformer = Transformer.Builder(this@VideoEditService)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(
                        composition: Composition,
                        exportResult: ExportResult
                    ) {
                        scope.launch { finishSuccess(outputTemp!!) }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        scope.launch {
                            finishError(
                                "Export failed after compatibility retry: " +
                                    exportException.errorCodeName
                            )
                        }
                    }
                })
                .build()

            transformer!!.start(safeComposition, outputTemp!!.absolutePath)
        }

        withContext(Dispatchers.Main.immediate) { pollProgress() }
    }

    private suspend fun pollProgress() {
        val holder = ProgressHolder()
        while (transformer != null && outputTemp?.exists() == true) {
            val state = transformer!!.getProgress(holder)
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                val raw = holder.progress / 100f
                val p = 0.62f + raw * 0.38f
                val elapsed = (SystemClock.elapsedRealtime() - startElapsed) / 1000L
                val eta = if (raw > 0.02f) ((elapsed / raw) - elapsed).toLong() else -1L
                setState(true, p, "Rendering video", "Media3 is encoding the final MP4…", eta, null, "")
                updateNotification("Rendering video", (p * 100).toInt())
            }
            if (state == Transformer.PROGRESS_STATE_NOT_STARTED) delay(500) else delay(500)
        }
    }

    private fun buildComposition(
        uri: Uri,
        segments: List<SpeechSegment>,
        captions: Boolean,
        smartCut: Boolean,
        silence: Boolean,
        reframe: Boolean,
        zoom: Boolean,
        color: Boolean,
        audio: Boolean,
        preset: String
    ): Composition {
        val useSegments = (smartCut || silence || captions) && segments.size > 1
        val clips = if (useSegments) {
            val padding = 120L
            val gapThreshold = 650L
            val merged = ArrayList<SpeechSegment>()
            for (seg in segments) {
                val s = max(0L, seg.startMs - padding)
                val e = seg.endMs + padding
                if (merged.isNotEmpty() && s - merged.last().endMs < gapThreshold) {
                    val last = merged.removeAt(merged.lastIndex)
                    merged.add(SpeechSegment(last.startMs, max(last.endMs, e), (last.text + " " + seg.text).trim()))
                } else merged.add(SpeechSegment(s, e, seg.text))
            }
            merged
        } else listOf(SpeechSegment(0, durationMs(uri), ""))

        val items = clips.map { seg ->
            val media = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(seg.startMs)
                        .setEndPositionMs(max(seg.startMs + 100, seg.endMs))
                        .build()
                ).build()

            val effects = mutableListOf<androidx.media3.common.Effect>()
            if (reframe) {
                val aspect = when (preset) { "SQUARE" -> 1f; "YOUTUBE" -> 16f / 9f; else -> 9f / 16f }
                effects.add(Presentation.createForAspectRatio(aspect, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
            }
            if (zoom) effects.add(ScaleAndRotateTransformation.Builder().setScale(1.04f, 1.04f).build())
            if (color) { effects.add(Brightness(0.03f)); effects.add(Contrast(0.06f)) }
            if (captions && seg.text.isNotBlank()) {
                val text = android.text.SpannableString(seg.text.take(140))
                val settings = StaticOverlaySettings.Builder()
                    .setBackgroundFrameAnchor(0f, -0.72f)
                    .setOverlayFrameAnchor(0f, -0.72f)
                    .build()
                effects.add(OverlayEffect(listOf(TextOverlay.createStaticTextOverlay(text, settings))))
            }

            val audioProcessors = mutableListOf<androidx.media3.common.audio.AudioProcessor>()
            if (silence) {
                val skip = SilenceSkippingAudioProcessor()
                skip.setEnabled(true)
                audioProcessors.add(skip)
            }
            if (audio) {
                // Media3's silence processor is the safe built-in offline audio cleanup path.
                // Extra gain/EQ is intentionally avoided to prevent clipping on unknown source audio.
            }
            EditedMediaItem.Builder(media).setEffects(Effects(audioProcessors, effects)).build()
        }
        // Keep the Java List overload explicit to avoid Kotlin constructor overload ambiguity.
        val immutableItems: List<EditedMediaItem> = items.toList()
        val sequence = EditedMediaItemSequence(immutableItems)
        val sequences: List<EditedMediaItemSequence> = listOf(sequence)
        return Composition.Builder(sequences).build()
    }

    private suspend fun downloadModel(file: File) {
        file.parentFile?.mkdirs()
        val tmp = File(file.parentFile, "$MODEL_NAME.part")
        val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 60_000
            instanceFollowRedirects = true
        }
        conn.connect()
        if (conn.responseCode !in 200..299) throw IllegalStateException("AI model download failed: HTTP ${conn.responseCode}")
        val total = conn.contentLengthLong
        var done = 0L
        conn.inputStream.use { input ->
            FileOutputStream(tmp).use { output ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    output.write(buf, 0, n)
                    done += n
                    val frac = if (total > 0) done.toFloat() / total else 0f
                    val p = 0.01f + frac * 0.14f
                    val elapsed = (SystemClock.elapsedRealtime() - startElapsed) / 1000L
                    val eta = if (frac > 0.02f) ((elapsed / frac) - elapsed).toLong() else -1L
                    setState(true, p, "Downloading AI model", "Whisper Base • ${(done / 1_000_000)} / ${(total / 1_000_000)} MB", eta, null, "")
                    updateNotification("Downloading AI model", (frac * 100).toInt())
                }
            }
        }
        if (tmp.length() < 50_000_000L) throw IllegalStateException("Downloaded AI model is incomplete")
        if (file.exists()) file.delete()
        if (!tmp.renameTo(file)) throw IllegalStateException("Could not store AI model")
    }

    private fun durationMs(uri: Uri): Long {
        val r = android.media.MediaMetadataRetriever()
        return try { r.setDataSource(this, uri); r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L }
        catch (_: Exception) { 0L } finally { r.release() }
    }

    private suspend fun finishSuccess(temp: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "FreeCut_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, android.os.Environment.DIRECTORY_MOVIES + "/FreeCut AI")
            }
            val saved = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Could not create output file")
            contentResolver.openOutputStream(saved)?.use { out -> temp.inputStream().use { it.copyTo(out) } }
            temp.delete()
            val elapsed = (SystemClock.elapsedRealtime() - startElapsed) / 1000L
            setState(false, 1f, "Complete ✓", "Saved to Movies/FreeCut AI", 0, saved, "")
            updateNotification("FreeCut AI complete", 100)
            stopNow()
        } catch (e: Exception) { finishError(e.message ?: "Saving failed") }
    }

    private fun finishError(message: String) {
        try { outputTemp?.delete() } catch (_: Exception) {}
        setState(false, 0f, "Failed", "", 0, null, message)
        updateNotification("FreeCut AI failed", 0)
        stopNow()
    }

    private fun setState(running: Boolean, progress: Float, stage: String, detail: String, eta: Long, output: Uri?, error: String) {
        val elapsed = (SystemClock.elapsedRealtime() - startElapsed) / 1000L
        EditStateStore.write(this, EditState(running, progress.coerceIn(0f, 1f), stage, detail, elapsed, eta, output?.toString(), error))
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "FreeCut AI Processing", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(text: String, progress: Int): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("FreeCut AI")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setProgress(100, progress.coerceIn(0, 100), false)
            .build()
    }

    private fun updateNotification(text: String, progress: Int) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text, progress))
    }

    private fun stopNow() {
        transformer = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        transformer = null
        scope.cancel()
        super.onDestroy()
    }
    

    private data class SpeechSegment(val startMs: Long, val endMs: Long, val text: String)
}
