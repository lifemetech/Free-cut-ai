package com.freecut.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlin.math.max

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
        setContent { FreeCutApp() }
    }

    fun startEdit(uri: Uri, mode: String, startMs: Long = 0L, endMs: Long = -1L, outputHeight: Int = 1080, preset: String = "SHORTS") {
        val intent = Intent(this, VideoEditService::class.java).apply {
            action = VideoEditService.ACTION_START
            data = uri
            putExtra(VideoEditService.EXTRA_MODE, mode)
            putExtra(VideoEditService.EXTRA_START_MS, startMs)
            putExtra(VideoEditService.EXTRA_END_MS, endMs)
            putExtra(VideoEditService.EXTRA_CAPTIONS, mode == VideoEditService.MODE_FULL_FAST || mode == VideoEditService.MODE_CAPTIONS)
            putExtra(VideoEditService.EXTRA_SMART_CUT, mode == VideoEditService.MODE_FULL_FAST || mode == VideoEditService.MODE_SMART_CUT)
            putExtra(VideoEditService.EXTRA_SILENCE, mode == VideoEditService.MODE_FULL_FAST || mode == VideoEditService.MODE_SILENCE)
            putExtra(VideoEditService.EXTRA_REFRAME, mode == VideoEditService.MODE_FULL_FAST || mode == VideoEditService.MODE_REFRAME || mode == VideoEditService.MODE_EXPORT_2K)
            // Fast mode intentionally skips auto-zoom. It can be run separately from the AI toolbar.
            putExtra(VideoEditService.EXTRA_ZOOM, mode == VideoEditService.MODE_ZOOM)
            putExtra(VideoEditService.EXTRA_COLOR, mode == VideoEditService.MODE_COLOR)
            putExtra(VideoEditService.EXTRA_AUDIO, mode == VideoEditService.MODE_AUDIO)
            putExtra(VideoEditService.EXTRA_PRESET, preset)
            putExtra(VideoEditService.EXTRA_OUTPUT_HEIGHT, outputHeight)
        }
        ContextCompat.startForegroundService(this, intent)
    }
}

@Composable
private fun FreeCutApp() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf<Uri?>(null) }
    var clip by remember { mutableStateOf<MediaClip?>(null) }
    var project by remember { mutableStateOf(ProjectSettings()) }
    var tool by remember { mutableStateOf(EditorTool.EDIT) }
    var captionStyle by remember { mutableStateOf(CaptionStyle.KINETIC_PRO) }
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(0L) }
    var linked by remember { mutableStateOf(true) }
    var rippleDelete by remember { mutableStateOf(true) }
    var history by remember { mutableStateOf(listOf<EditCommand>()) }
    var undone by remember { mutableStateOf(listOf<EditCommand>()) }
    var state by remember { mutableStateOf(EditState()) }
    var showProject by remember { mutableStateOf(false) }
    var showRetention by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selected = uri
            val d = durationMs(context, uri)
            clip = MediaClip(System.currentTimeMillis(), uri, "Source Video", d)
            startMs = 0L
            endMs = d
            project = project.copy(name = "My YouTube Project")
            history = listOf(EditCommand.AddClip(clip!!))
            undone = emptyList()
            state = EditState()
        }
    }

    LaunchedEffect(Unit) {
        while (true) { state = EditStateStore.read(context); delay(500) }
    }

    fun record(command: EditCommand) {
        history = history + command
        undone = emptyList()
    }

    fun run(mode: String, height: Int = if (project.resolution == "2K") 2560 else 1080) {
        val uri = selected ?: return
        (context as? MainActivity)?.startEdit(uri, mode, startMs, endMs, height)
        record(EditCommand.ApplyTool(EditorTool.AI, mode))
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(102, 76, 180))) {
        Surface(Modifier.fillMaxSize()) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("FreeCut AI", fontSize = 29.sp, fontWeight = FontWeight.Bold)
                            Text("Professional editor • AI retention • non-destructive")
                        }
                        Text("5.0", style = MaterialTheme.typography.labelLarge)
                    }
                }

                item {
                    Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column {
                                    Text("PROJECT", style = MaterialTheme.typography.labelLarge)
                                    Text(project.name, style = MaterialTheme.typography.titleLarge)
                                }
                                TextButton(onClick = { showProject = true }) { Text("SETTINGS") }
                            }
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                AssistChip(onClick = { project = project.copy(aspectRatio = "9:16") }, label = { Text("9:16") })
                                AssistChip(onClick = { project = project.copy(aspectRatio = "16:9") }, label = { Text("16:9") })
                                AssistChip(onClick = { project = project.copy(resolution = if (project.resolution == "2K") "1080p" else "2K") }, label = { Text(project.resolution) })
                                AssistChip(onClick = { project = project.copy(fps = if (project.fps == 30) 60 else 30) }, label = { Text("${project.fps} FPS") })
                            }
                        }
                    }
                }

                item {
                    if (selected == null) {
                        Button(onClick = { picker.launch("video/*") }, Modifier.fillMaxWidth().height(52.dp)) { Text("＋ IMPORT VIDEO") }
                    } else {
                        OutlinedButton(onClick = { picker.launch("video/*") }, Modifier.fillMaxWidth()) { Text("CHANGE VIDEO") }
                    }
                }

                if (selected != null) {
                    item { VideoPreview(selected!!, state.running) }
                    item {
                        TimelineCard(
                            clip, startMs, endMs, linked, rippleDelete,
                            onStart = { startMs = it.coerceIn(0L, max(0L, endMs - 100L)); clip = clip?.copy(startMs = startMs) },
                            onEnd = { endMs = it.coerceIn(minOf(startMs + 100L, clip?.durationMs ?: it), clip?.durationMs ?: it); clip = clip?.copy(endMs = endMs) },
                            onSplit = {
                                val c = clip ?: return@TimelineCard
                                val mid = ((startMs + endMs) / 2L).coerceIn(startMs + 100L, endMs - 100L)
                                record(EditCommand.Split(c.id, mid))
                            },
                            onDelete = {
                                clip?.let { record(EditCommand.Delete(it.id)) }
                                selected = null
                                clip = null
                            },
                            setLinked = { linked = it },
                            setRippleDelete = { rippleDelete = it }
                        )
                    }

                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            OutlinedButton(onClick = { if (history.isNotEmpty()) { undone = undone + history.last(); history = history.dropLast(1) } }, enabled = history.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("↶ UNDO") }
                            OutlinedButton(onClick = { if (undone.isNotEmpty()) { history = history + undone.last(); undone = undone.dropLast(1) } }, enabled = undone.isNotEmpty(), modifier = Modifier.weight(1f)) { Text("↷ REDO") }
                        }
                    }

                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column { Text("AI HIGH RETENTION", fontWeight = FontWeight.Bold); Text("Second-by-second decision engine") }
                                    Button(onClick = { showRetention = true }) { Text("ANALYZE") }
                                }
                                Text("No fixed 1-second effect rule: AI varies density for hook, action, problem, emotion and payoff.")
                            }
                        }
                    }

                    item {
                        Text("TOOLS", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            EditorTool.values().forEach { t ->
                                FilterChip(selected = tool == t, onClick = { tool = t }, label = { Text("${t.icon} ${t.label}") })
                            }
                        }
                    }

                    item { ToolPanel(tool, captionStyle, { captionStyle = it }, onRun = { mode, height -> run(mode, height) }) }

                    if (state.running || state.progress > 0f) {
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Text(state.stage, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    LinearProgressIndicator(progress = { state.progress }, Modifier.fillMaxWidth())
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("${(state.progress * 100).toInt()}%")
                                        Text("Elapsed ${formatSeconds(state.elapsedSec)}")
                                    }
                                    Text(state.detail)
                                }
                            }
                        }
                    }

                    if (!state.running && state.outputUri != null) {
                        item {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("EXPORT READY ✓", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("Saved in Movies/FreeCut AI")
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = { selected = Uri.parse(state.outputUri) }, modifier = Modifier.weight(1f)) { Text("USE RESULT") }
                                        OutlinedButton(onClick = {
                                            val send = Intent(Intent.ACTION_SEND).apply { type = "video/mp4"; putExtra(Intent.EXTRA_STREAM, Uri.parse(state.outputUri)); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                                            context.startActivity(Intent.createChooser(send, "Share FreeCut AI video"))
                                        }, modifier = Modifier.weight(1f)) { Text("SHARE") }
                                    }
                                }
                            }
                        }
                    }
                    if (state.error.isNotBlank()) item { Text(state.error, color = MaterialTheme.colorScheme.error) }
                }
            }
        }
    }

    if (showProject) {
        AlertDialog(
            onDismissRequest = { showProject = false },
            title = { Text("Project Settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Aspect: ${project.aspectRatio}")
                    Text("Resolution: ${project.resolution} (2K = 1440×2560 target)")
                    Text("FPS: ${project.fps}")
                    Text("Original media remains unchanged; edits are represented as commands.")
                }
            },
            confirmButton = { TextButton(onClick = { showProject = false }) { Text("DONE") } }
        )
    }

    if (showRetention) {
        val plan = RetentionEngine.build(clip?.durationMs ?: 600_000L)
        AlertDialog(
            onDismissRequest = { showRetention = false },
            title = { Text("AI High Retention Plan • ${plan.score}/100") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.heightIn(max = 420.dp)) {
                    item { Text("Editing density is adaptive, not one effect per second.") }
                    items(plan.decisions.take(90)) { d ->
                        Text("${formatSeconds(d.second * 1000L)}  ${d.role.name} • ${d.density.name} • ${d.action}")
                    }
                    item { Text("Review before Apply. AI changes are intended to remain editable.") }
                }
            },
            confirmButton = { TextButton(onClick = { showRetention = false }) { Text("CLOSE") } }
        )
    }

}

@Composable
private fun VideoPreview(uri: Uri, processing: Boolean) {
    val context = LocalContext.current
    val player = remember(uri) { ExoPlayer.Builder(context).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare() } }
    DisposableEffect(player) { onDispose { player.release() } }
    Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().height(330.dp)) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxSize())
            if (processing) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
        }
    }
}

@Composable
private fun TimelineCard(
    clip: MediaClip?, start: Long, end: Long, linked: Boolean, rippleDelete: Boolean,
    onStart: (Long) -> Unit, onEnd: (Long) -> Unit, onSplit: () -> Unit, onDelete: () -> Unit,
    setLinked: (Boolean) -> Unit, setRippleDelete: (Boolean) -> Unit
) {
    val duration = clip?.durationMs?.coerceAtLeast(1000L) ?: 1000L
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text("TIMELINE", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Box(Modifier.fillMaxWidth().height(46.dp).background(Color(35,35,40), RoundedCornerShape(10.dp))) {
                    Text("VIDEO 1  •  ${formatSeconds(start)} — ${formatSeconds(end)}", color = Color.White, modifier = Modifier.align(Alignment.Center))
                }
                Text("Start ${formatSeconds(start)}")
                Slider(value = start.toFloat(), onValueChange = { onStart(it.toLong()) }, valueRange = 0f..(duration - 100).coerceAtLeast(0L).toFloat())
                Text("End ${formatSeconds(end)}")
                Slider(value = end.toFloat(), onValueChange = { onEnd(it.toLong()) }, valueRange = (start + 100).coerceAtMost(duration).toFloat()..duration.toFloat())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Linked audio")
                    Switch(checked = linked, onCheckedChange = setLinked)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Ripple delete")
                    Switch(checked = rippleDelete, onCheckedChange = setRippleDelete)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Button(onClick = onSplit, modifier = Modifier.weight(1f)) { Text("SPLIT") }
                    OutlinedButton(onClick = onDelete, modifier = Modifier.weight(1f)) { Text("DELETE") }
                }
            }
        }
    }
}

@Composable
private fun ToolPanel(tool: EditorTool, captionStyle: CaptionStyle, setCaptionStyle: (CaptionStyle) -> Unit, onRun: (String, Int) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(tool.label.uppercase(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            when (tool) {
                EditorTool.EDIT -> {
                    Text("Manual, non-destructive editing")
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Button(onClick = { onRun(VideoEditService.MODE_TRIM, 1080) }, modifier = Modifier.weight(1f)) { Text("APPLY TRIM") }
                        OutlinedButton(onClick = { onRun(VideoEditService.MODE_REFRAME, 1080) }, modifier = Modifier.weight(1f)) { Text("9:16 REFRAME") }
                    }
                }
                EditorTool.EFFECTS -> {
                    Text("Fast effects are separate so you can apply only what you need.")
                    Button(onClick = { onRun(VideoEditService.MODE_COLOR, 1080) }, Modifier.fillMaxWidth()) { Text("COLOR ENHANCE") }
                    OutlinedButton(onClick = { onRun(VideoEditService.MODE_ZOOM, 1080) }, Modifier.fillMaxWidth()) { Text("AUTO ZOOM") }
                }
                EditorTool.TEXT -> {
                    Text("Advanced kinetic caption presets")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        CaptionStyle.values().forEach { s -> FilterChip(captionStyle == s, { setCaptionStyle(s) }, label = { Text(s.label) }) }
                    }
                    Text("Primary preset: one-word kinetic captions. Current release estimates word timing from local speech segments.")
                    Button(onClick = { onRun(VideoEditService.MODE_CAPTIONS, 1080) }, Modifier.fillMaxWidth()) { Text("GENERATE KINETIC CAPTIONS") }
                }
                EditorTool.AUDIO -> {
                    Text("Apply only audio processing when needed for faster editing.")
                    Button(onClick = { onRun(VideoEditService.MODE_AUDIO, 1080) }, Modifier.fillMaxWidth()) { Text("ENHANCE AUDIO") }
                }
                EditorTool.AI -> {
                    Text("High-retention AI changes density according to story purpose.")
                    Button(onClick = { onRun(VideoEditService.MODE_FULL_FAST, 1080) }, Modifier.fillMaxWidth()) { Text("⚡ FAST HIGH-RETENTION EDIT") }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { onRun(VideoEditService.MODE_SMART_CUT, 1080) }, modifier = Modifier.weight(1f)) { Text("AUTO CUT") }
                        OutlinedButton(onClick = { onRun(VideoEditService.MODE_SILENCE, 1080) }, modifier = Modifier.weight(1f)) { Text("SILENCE") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { onRun(VideoEditService.MODE_ZOOM, 1080) }, modifier = Modifier.weight(1f)) { Text("AUTO ZOOM") }
                        OutlinedButton(onClick = { onRun(VideoEditService.MODE_CAPTIONS, 1080) }, modifier = Modifier.weight(1f)) { Text("CAPTIONS") }
                    }
                }
                EditorTool.GRAPHICS -> {
                    Text("Vector-style layer foundation")
                    Text("Arrow • Circle • Box • Spotlight • Counter • Timer • Progress")
                }
                EditorTool.SPEED -> {
                    Text("Speed ramp foundation: Action • Cinematic • Sports • Impact")
                }
                EditorTool.ANIMATION -> {
                    Text("Keyframes: Position • Scale • Rotation • Opacity • Blur")
                }
                EditorTool.MORE -> {
                    Text("Export and advanced utilities")
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Button(onClick = { onRun(VideoEditService.MODE_REFRAME, 1080) }, modifier = Modifier.weight(1f)) { Text("9:16") }
                        Button(onClick = { onRun(VideoEditService.MODE_EXPORT_2K, 2560) }, modifier = Modifier.weight(1f)) { Text("EXPORT 2K") }
                    }
                }
            }
        }
    }
}

private fun durationMs(context: android.content.Context, uri: Uri): Long {
    val r = android.media.MediaMetadataRetriever()
    return try { r.setDataSource(context, uri); r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L } catch (_: Exception) { 0L } finally { r.release() }
}

private fun formatSeconds(ms: Long): String {
    val sec = (ms / 1000L).coerceAtLeast(0L)
    return "%02d:%02d.%01d".format(sec / 60, sec % 60, (ms % 1000) / 100)
}
